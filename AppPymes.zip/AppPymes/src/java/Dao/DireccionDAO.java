/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Modelo.Conexion;
import Modelo.Direccion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author AngieRiera
 */
public class DireccionDAO {

    PreparedStatement ps = null;
    ResultSet rs = null;
    
    public String id() {
        String vId = "";

        try {
            Conexion con = new Conexion();
            Connection conexion = con.getConnection();
            PreparedStatement ps;
            ResultSet rs;
            
            ps = conexion.prepareStatement("select max(id) from direccion");
            rs = ps.executeQuery();

            while (rs.next()) {
                vId = rs.getString(1);
            }
        } catch (Exception e) {
            
        }
        return vId;
    }

    public boolean agregar(Direccion direccion) {
        Conexion con = new Conexion();
        Connection conexion = con.getConnection();
        boolean estado = false;

        try {
            ps = conexion.prepareStatement("INSERT INTO DIRECCION (DESCRIPCION, ID_COMUNA) VALUES (?,?)");
            ps.setString(1, direccion.getDireccion());
            ps.setInt(1, direccion.getComuna());
        } catch (Exception ex) {
            System.err.println("Error, " + ex);
            estado = false;
        }
        return estado;
    }
}
